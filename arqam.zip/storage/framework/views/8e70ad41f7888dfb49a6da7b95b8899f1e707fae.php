

<?php $__env->startSection('content'); ?>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <h1>Welcome to <span>Madrasa Dar-e-Arqam</span></h1>
      <h2>We provide education that leads to a successful life in Dunya and Aakhirat</h2>
      
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
    
    <!-- ======= About Section ======= -->
    
    <!-- ======= Skills Section ======= -->
    
    <!-- ======= Counts Section ======= -->
    
    <!-- ======= Clients Section ======= -->
    
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Courses</h2>
          <h3>Check our <span>Courses</span></h3>
          <p>Check out our courses given below with complete details.</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="">Ilm-e-deen<br></a></h4>
              <h4><a href="">Tahleem-e-Balghan<br><small>Male</small></a></h4>
              <p>This course is designed for those who are 15+ for more deatails <a href="#"> click here.</a></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="">Tahleem-e-balghan <small>Female</small></a></h4>
              <p>This course is designed for those who are 15+ for more deatails <a href="#"> click here.</a></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="">Nazra</a></h4>
              <p>This course has no age criteria everyone is eligible for this course. For more details<a href="#"> click here.</a></p>
            </div>
          </div>

         
        </div>

      </div>
    </section><!-- End Services Section -->
    <div class="section-title">
      <h2>Faculty</h2>
      <h3>Our  <span>Faculty</span></h3>
      <p>Our faculties are well qualified and masters in their subjects</p>
    </div>
    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Abdul Mateen</h3>
                <h4>Principal &amp; Founder</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Muhammad Yousuf</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Mufti Muhammad Asad</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Abdul Latif</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Bilal</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->
            
            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Hafiz Maqbool</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Munawwar</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="#" class="testimonial-img" alt="">
                <h3>Molana Abdullah</h3>
                <h4>Teacher</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  TEXT GOES HERE
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Audios</h2>
          <h3>Check our <span>Audios</span></h3>
          <p>Here You will find Our latest News from here.</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">Audios</li>
              <li data-filter=".filter-card">Darse Quran</li>
              <li data-filter=".filter-web">Darse Hadees</li>
              <li data-filter=".filter-web">Fiqh</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          

        </div>

      </div>

      
    </section><!-- End Portfolio Section -->

       <!-- ======= Portfolio Section ======= -->
       <section id="portfolio" class="portfolio">
        <div class="container" data-aos="fade-up">
  
          <div class="section-title">
            <h2>Publication</h2>
            <h3>Check our <span>Publications</span></h3>
            <p>Here You will find Our latest Publications from here.</p>
          </div>
  
          <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col-lg-12 d-flex justify-content-center">
              <ul id="portfolio-flters">
                <li data-filter="*" class="filter-active">All</li>
                <li data-filter=".filter-card">Books</li>
                <li data-filter=".filter-app">Articles</li>
                
                <li data-filter=".filter-web">Notes</li>
                
              </ul>
            </div>
          </div>
  
          <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
   

          </div>

        </div>
  
        
      </section><!-- End Portfolio Section -->
  
    <!-- ======= Team Section ======= -->
    
    <!-- ======= Pricing Section ======= -->
   
    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>F.A.Q</h2>
          <h3>Frequently Asked <span>Questions</span></h3>
          <p>Some of Frequent questions are answered below by principal.</p>
        </div>

        <div class="row justify-content-center">
          <div class="col-xl-10">
            <ul class="faq-list">

              <li>
                <div data-bs-toggle="collapse" class="collapsed question" href="#faq1">All the courses are free ? Or you charge for some courses ? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq1" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    Dear All courses are free we provide free eductaion.
                  </p>
                </div>
              </li>

              <li>
                <div data-bs-toggle="collapse" href="#faq2" class="collapsed question">Is this madrasa has seperate teachers for every subject ? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq2" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    Yes we have subject specialist teachers for every subject.
                  </p>
                </div>
              </li>

              <li>
                <div data-bs-toggle="collapse" href="#faq3" class="collapsed question"> How can I contribute with Madrasa ? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></div>
                <div id="faq3" class="collapse" data-bs-parent=".faq-list">
                  <p>
                    You can contribute with us by our jazz cash account. Abdul Mateen: 03042632096
                  </p>
                </div>
              </li>

              
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <h3><span>Contact Us</span></h3>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-3">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>Lyari Nawalane, Street No:18</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>abdulmateen989@yahoo.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+92 304 2632096</p>
              
            </div>
          </div>
            
          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>WhatsApp</h3>
              <p>+92 322 2582957</p>
              
            </div>
          </div>

        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6 ">
            <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\arqam\resources\views/index.blade.php ENDPATH**/ ?>